Nik Visuals 3.8

New:
- Combo counter (2x+) with pop animation
- Hit marker on swing
- Totem indicator near hotbar
- Low HP red vignette
- Menu tab fade transition
- Spring animations on Target HUD / combo

Build: gradlew.bat build → nikvisuals-3.8.jar
